import React, { useState } from 'react';
import { Info, Globe, Shield, Activity, FileText, X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import VisualIntelligence from './components/VisualIntelligence';
import DataAnalytics from './components/DataAnalytics';
import CivicReporting from './components/CivicReporting';
import { Language, VisionResult } from './types';
import { translations } from './utils/translations';

export default function App() {
  const [activeTab, setActiveTab] = useState<'vision' | 'analytics' | 'reporting'>('vision');
  const [language, setLanguage] = useState<Language>('en');
  const [showAbout, setShowAbout] = useState(false);
  
  const [hazardResult, setHazardResult] = useState<VisionResult | null>(null);
  const [analyticsInsights, setAnalyticsInsights] = useState('');
  const [selectedLocation, setSelectedLocation] = useState('');

  const t = translations[language];

  return (
    <div className="min-h-screen pb-20">
      {/* Navbar */}
      <nav className="sticky top-0 z-50 bg-white/70 backdrop-blur-2xl border-b border-white/20 px-6 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-indigo-600 rounded-2xl flex items-center justify-center shadow-lg shadow-indigo-200">
              <Shield className="text-white" size={28} />
            </div>
            <h1 className="text-5xl font-black tracking-tighter bg-gradient-to-r from-[#0A1D56] to-[#6D28D9] bg-clip-text text-transparent">
              {t.appTitle}
            </h1>
          </div>

          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 bg-slate-100 p-1.5 rounded-2xl">
              <Globe size={18} className="text-slate-500 ml-2" />
              <select 
                value={language}
                onChange={(e) => setLanguage(e.target.value as Language)}
                className="bg-transparent border-none outline-none text-sm font-bold text-slate-700 pr-4"
              >
                <option value="en">English</option>
                <option value="hi">हिन्दी</option>
                <option value="ta">தமிழ்</option>
                <option value="te">తెలుగు</option>
                <option value="es">Español</option>
                <option value="fr">Français</option>
                <option value="kn">ಕನ್ನಡ</option>
                <option value="ml">മലയാളം</option>
              </select>
            </div>
            
            <button 
              onClick={() => setShowAbout(true)}
              className="w-10 h-10 flex items-center justify-center bg-slate-100 hover:bg-slate-200 rounded-full transition-colors text-slate-600"
            >
              <Info size={20} />
            </button>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-6 mt-12">
        {/* Navigation Tabs */}
        <div className="flex flex-wrap gap-4 mb-12">
          <TabButton 
            active={activeTab === 'vision'} 
            onClick={() => setActiveTab('vision')}
            icon={<Shield size={20} />}
            label={t.visualIntel}
          />
          <TabButton 
            active={activeTab === 'analytics'} 
            onClick={() => setActiveTab('analytics')}
            icon={<Activity size={20} />}
            label={t.dataAnalytics}
          />
          <TabButton 
            active={activeTab === 'reporting'} 
            onClick={() => setActiveTab('reporting')}
            icon={<FileText size={20} />}
            label={t.civicReporting}
          />
        </div>

        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: -20, opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            {activeTab === 'vision' && (
              <VisualIntelligence 
                language={language} 
                t={t} 
                onResult={setHazardResult}
                onProceed={() => setActiveTab('reporting')}
              />
            )}
            {activeTab === 'analytics' && (
              <DataAnalytics 
                language={language} 
                t={t} 
                onLocationSelect={setSelectedLocation}
              />
            )}
            {activeTab === 'reporting' && (
              <CivicReporting 
                language={language} 
                t={t} 
                hazardResult={hazardResult}
                analyticsInsights={analyticsInsights || "Historical data analysis pending."}
                selectedLocation={selectedLocation || "Location not specified"}
              />
            )}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* About Modal */}
      <AnimatePresence>
        {showAbout && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-6">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowAbout(false)}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-md" 
            />
            <motion.div 
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="relative w-full max-w-2xl bg-white rounded-[40px] p-12 shadow-2xl overflow-hidden"
            >
              <div className="absolute top-0 left-0 w-full h-3 bg-indigo-600" />
              <button 
                onClick={() => setShowAbout(false)}
                className="absolute top-8 right-8 p-2 hover:bg-slate-100 rounded-full transition-colors"
              >
                <X size={24} className="text-slate-400" />
              </button>
              
              <h2 className="text-4xl font-black mb-8 text-slate-800">About ROAD MAP</h2>
              <div className="prose prose-indigo prose-lg text-slate-600 leading-relaxed">
                <p>
                  ROAD MAP is a comprehensive smart road-safety system designed to enhance civic infrastructure through multimodal artificial intelligence. The platform begins by empowering citizens with visual intelligence, allowing them to capture and analyze road hazards such as potholes, broken streetlights, or waterlogging using live camera feeds and audio descriptions.
                </p>
                <p>
                  Complementing this real-time detection, the system integrates a robust data analytics engine that processes historical accident datasets to identify high-risk hotspots, common causes of road incidents, and temporal patterns.
                </p>
                <p>
                  By merging these live observations with historical insights, ROAD MAP automatically generates professional, data-backed complaint letters addressed to the appropriate local authorities. The system validates the selected authority for the specific hazard type and provides a digital tracking mechanism, ensuring a seamless and accountable reporting workflow.
                </p>
              </div>
              <div className="mt-12 pt-8 border-t border-slate-100 flex justify-between items-center">
                <span className="text-sm font-bold text-slate-400 uppercase tracking-widest">B.Tech Project Prototype</span>
                <button 
                  onClick={() => setShowAbout(false)}
                  className="px-8 py-3 bg-slate-900 text-white rounded-2xl font-bold"
                >
                  Got it
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

function TabButton({ active, onClick, icon, label }: { active: boolean; onClick: () => void; icon: React.ReactNode; label: string }) {
  return (
    <button
      onClick={onClick}
      className={`flex items-center gap-3 px-8 py-4 rounded-2xl font-bold transition-all ${
        active 
          ? 'bg-white text-indigo-600 shadow-xl shadow-indigo-100 scale-105' 
          : 'bg-white/40 text-slate-600 hover:bg-white/60'
      }`}
    >
      {icon}
      {label}
    </button>
  );
}
