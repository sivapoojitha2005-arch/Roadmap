import React, { useState, useEffect } from 'react';
import { FileText, Send, UserCheck, ShieldAlert, CheckCircle2, Loader2, MapPin, Clock } from 'lucide-react';
import Markdown from 'react-markdown';
import { motion, AnimatePresence } from 'motion/react';
import { VisionResult, Language, TranslationStrings, Authority } from '../types';
import { generateComplaintLetter, validateAuthority } from '../services/geminiService';

interface Props {
  language: Language;
  t: TranslationStrings;
  hazardResult: VisionResult | null;
  analyticsInsights: string;
  selectedLocation: string;
}

const AUTHORITIES: Authority[] = [
  { id: '1', name: 'Municipal Commissioner', role: 'Commissioner', department: 'Municipal Corporation' },
  { id: '2', name: 'Traffic Police Chief', role: 'Police Inspector', department: 'Traffic Department' },
  { id: '3', name: 'Ward Engineer', role: 'Engineer', department: 'Public Works' },
  { id: '4', name: 'Streetlight In-charge', role: 'Officer', department: 'Electrical Dept' },
];

export default function CivicReporting({ language, t, hazardResult, analyticsInsights, selectedLocation }: Props) {
  const [selectedAuthority, setSelectedAuthority] = useState<Authority | null>(null);
  const [letter, setLetter] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [isSending, setIsSending] = useState(false);
  const [isSent, setIsSent] = useState(false);
  const [validation, setValidation] = useState<{ isCorrect: boolean; message: string } | null>(null);
  const [isValidating, setIsValidating] = useState(false);

  useEffect(() => {
    if (selectedAuthority && hazardResult) {
      handleValidate();
    }
  }, [selectedAuthority, hazardResult]);

  const handleValidate = async () => {
    if (!selectedAuthority || !hazardResult) return;
    setIsValidating(true);
    try {
      const res = await validateAuthority(hazardResult.hazardType, selectedAuthority.role, language);
      setValidation(res);
    } catch (err) {
      console.error(err);
    } finally {
      setIsValidating(false);
    }
  };

  const handleGenerate = async () => {
    if (!hazardResult || !selectedAuthority) return;
    setIsGenerating(true);
    try {
      const res = await generateComplaintLetter(
        hazardResult,
        analyticsInsights,
        selectedAuthority.name,
        selectedLocation,
        language
      );
      setLetter(res);
    } catch (err) {
      console.error(err);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleSend = () => {
    setIsSending(true);
    setTimeout(() => {
      setIsSending(false);
      setIsSent(true);
    }, 2000);
  };

  return (
    <div className="space-y-6">
      <div className="bg-white/80 backdrop-blur-xl rounded-3xl p-8 shadow-2xl border border-white/20">
        <h2 className="text-3xl font-bold mb-8 flex items-center gap-3">
          <FileText className="text-indigo-600" size={32} />
          {t.civicReporting}
        </h2>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Authority Selection */}
          <div className="space-y-6">
            <div className="p-6 bg-slate-50 rounded-2xl border border-slate-100">
              <h3 className="text-sm font-bold text-slate-400 uppercase tracking-wider mb-4">Select Authority</h3>
              <div className="space-y-3">
                {AUTHORITIES.map((auth) => (
                  <button
                    key={auth.id}
                    onClick={() => setSelectedAuthority(auth)}
                    className={`w-full p-4 rounded-xl text-left transition-all border-2 ${
                      selectedAuthority?.id === auth.id 
                        ? 'bg-indigo-600 border-indigo-600 text-white shadow-lg' 
                        : 'bg-white border-slate-100 text-slate-600 hover:border-indigo-200'
                    }`}
                  >
                    <p className="font-bold">{auth.name}</p>
                    <p className={`text-xs ${selectedAuthority?.id === auth.id ? 'text-indigo-100' : 'text-slate-400'}`}>
                      {auth.role} • {auth.department}
                    </p>
                  </button>
                ))}
              </div>
            </div>

            <AnimatePresence>
              {validation && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className={`p-6 rounded-2xl border-2 ${
                    validation.isCorrect ? 'bg-emerald-50 border-emerald-100 text-emerald-700' : 'bg-amber-50 border-amber-100 text-amber-700'
                  }`}
                >
                  <div className="flex items-center gap-2 mb-2 font-bold">
                    {validation.isCorrect ? <UserCheck size={20} /> : <ShieldAlert size={20} />}
                    {t.authorityValidation}
                  </div>
                  <p className="text-sm">{validation.message}</p>
                  {validation.isCorrect && (
                    <div className="mt-4 px-3 py-1 bg-emerald-500 text-white text-[10px] font-black rounded-full w-fit uppercase tracking-tighter">
                      Recommended Match
                    </div>
                  )}
                </motion.div>
              )}
            </AnimatePresence>

            <button
              onClick={handleGenerate}
              disabled={!selectedAuthority || !hazardResult || isGenerating}
              className="w-full py-4 bg-indigo-600 text-white rounded-2xl font-bold shadow-xl shadow-indigo-100 disabled:opacity-50 flex items-center justify-center gap-2"
            >
              {isGenerating ? <Loader2 className="animate-spin" /> : <FileText size={20} />}
              {t.generateLetter}
            </button>
          </div>

          {/* Letter Preview */}
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-white rounded-3xl shadow-inner border border-slate-100 min-h-[500px] p-10 relative overflow-hidden">
              <div className="absolute top-0 left-0 w-full h-2 bg-indigo-600" />
              
              {isGenerating ? (
                <div className="absolute inset-0 flex flex-col items-center justify-center text-slate-400 gap-4">
                  <Loader2 size={48} className="animate-spin text-indigo-600" />
                  <p className="font-bold">Drafting formal complaint...</p>
                </div>
              ) : letter ? (
                <div className="prose prose-slate max-w-none">
                  <Markdown>{letter}</Markdown>
                </div>
              ) : (
                <div className="h-full flex flex-col items-center justify-center text-slate-300 gap-4">
                  <FileText size={80} className="opacity-10" />
                  <p className="text-center font-medium max-w-xs">
                    Complete the hazard analysis and select an authority to generate the official report.
                  </p>
                </div>
              )}

              {letter && !isSent && (
                <div className="mt-10 pt-10 border-t border-slate-100 flex justify-end">
                  <button
                    onClick={handleSend}
                    disabled={isSending}
                    className="px-10 py-4 bg-indigo-600 text-white rounded-2xl font-black text-xl shadow-2xl shadow-indigo-200 hover:bg-indigo-700 transition-all flex items-center gap-3 group"
                  >
                    {isSending ? <Loader2 className="animate-spin" /> : <Send size={24} />}
                    {t.sendReport}
                    {!isSending && <CheckCircle2 className="opacity-0 group-hover:opacity-100 transition-opacity" />}
                  </button>
                </div>
              )}
            </div>

            <AnimatePresence>
              {isSent && (
                <motion.div
                  initial={{ scale: 0.9, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  className="bg-slate-900 text-white p-8 rounded-3xl shadow-2xl border border-slate-800 relative overflow-hidden"
                >
                  <div className="absolute top-0 right-0 p-4 opacity-10">
                    <CheckCircle2 size={120} />
                  </div>
                  
                  <div className="flex items-center gap-4 mb-6">
                    <div className="w-16 h-16 bg-emerald-500 rounded-full flex items-center justify-center">
                      <CheckCircle2 size={32} />
                    </div>
                    <div>
                      <h3 className="text-2xl font-black uppercase tracking-tighter">Report Submitted</h3>
                      <p className="text-slate-400 font-medium">Ticket ID: #RM-{Math.floor(Math.random() * 90000) + 10000}</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4 mb-6">
                    <div className="bg-white/5 p-4 rounded-xl">
                      <p className="text-[10px] uppercase font-bold text-slate-500 mb-1">Status</p>
                      <p className="text-emerald-400 font-bold">SENT TO PORTAL</p>
                    </div>
                    <div className="bg-white/5 p-4 rounded-xl">
                      <p className="text-[10px] uppercase font-bold text-slate-500 mb-1">Recipient</p>
                      <p className="font-bold">{selectedAuthority?.name}</p>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <div className="flex items-center gap-3 text-sm text-slate-400">
                      <MapPin size={16} />
                      {selectedLocation}
                    </div>
                    <div className="flex items-center gap-3 text-sm text-slate-400">
                      <Clock size={16} />
                      Sent on {new Date().toLocaleString()}
                    </div>
                  </div>

                  <div className="mt-8 pt-6 border-t border-white/10 flex justify-between items-center">
                    <span className="text-xs font-bold text-slate-500">DIGITAL TRACKING RECEIPT</span>
                    <button className="text-indigo-400 text-xs font-bold hover:underline">Download PDF Copy</button>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>
    </div>
  );
}
