import React, { useState } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { Database, Upload, Search, MapPin, FileText, Loader2 } from 'lucide-react';
import Papa from 'papaparse';
import { AccidentData, Language, TranslationStrings } from '../types';
import { generateAnalyticsInsights } from '../services/geminiService';

interface Props {
  language: Language;
  t: TranslationStrings;
  onLocationSelect: (location: string) => void;
}

const COLORS = ['#4338ca', '#6366f1', '#818cf8', '#a5b4fc', '#c7d2fe'];

export default function DataAnalytics({ language, t, onLocationSelect }: Props) {
  const [data, setData] = useState<AccidentData[]>([]);
  const [search, setSearch] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [insights, setInsights] = useState('');
  const [selectedLocation, setSelectedLocation] = useState('');

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      Papa.parse(file, {
        header: true,
        complete: async (results) => {
          const parsedData = results.data as AccidentData[];
          setData(parsedData);
          setIsAnalyzing(true);
          const aiInsights = await generateAnalyticsInsights(parsedData, language);
          setInsights(aiInsights);
          setIsAnalyzing(false);
        }
      });
    }
  };

  const handleSearch = () => {
    if (!search) return;
    setSelectedLocation(search);
    onLocationSelect(search);
    // Simulate data for search if no CSV uploaded
    if (data.length === 0) {
      const mockData: AccidentData[] = [
        { location: search, time: '10:00 PM', severity: 'High', cause: 'Bad Road' },
        { location: search, time: '02:00 AM', severity: 'Medium', cause: 'Speeding' },
        { location: search, time: '11:30 PM', severity: 'High', cause: 'Pothole' },
      ];
      setData(mockData);
    }
  };

  const locationStats = data.reduce((acc: any, curr) => {
    acc[curr.location] = (acc[curr.location] || 0) + 1;
    return acc;
  }, {});

  const chartData = Object.entries(locationStats)
    .map(([name, count]) => ({ name, count }))
    .sort((a: any, b: any) => b.count - a.count)
    .slice(0, 5);

  const causeStats = data.reduce((acc: any, curr) => {
    acc[curr.cause] = (acc[curr.cause] || 0) + 1;
    return acc;
  }, {});

  const pieData = Object.entries(causeStats).map(([name, value]) => ({ name, value }));

  return (
    <div className="space-y-6">
      <div className="bg-white/80 backdrop-blur-xl rounded-3xl p-8 shadow-2xl border border-white/20">
        <h2 className="text-3xl font-bold mb-8 flex items-center gap-3">
          <Database className="text-indigo-600" size={32} />
          {t.dataAnalytics}
        </h2>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Controls */}
          <div className="space-y-6">
            <div className="p-6 bg-slate-50 rounded-2xl border border-slate-100">
              <label className="block text-sm font-bold text-slate-400 uppercase tracking-wider mb-4">
                {t.uploadCsv}
              </label>
              <div className="relative">
                <input 
                  type="file" 
                  accept=".csv" 
                  onChange={handleFileUpload}
                  className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                />
                <div className="flex flex-col items-center justify-center py-8 border-2 border-dashed border-slate-200 rounded-xl bg-white hover:bg-indigo-50 transition-colors">
                  <Upload className="text-indigo-400 mb-2" />
                  <span className="text-sm font-medium text-slate-500">Drop CSV here or click</span>
                </div>
              </div>
            </div>

            <div className="p-6 bg-slate-50 rounded-2xl border border-slate-100">
              <label className="block text-sm font-bold text-slate-400 uppercase tracking-wider mb-4">
                {t.searchLocation}
              </label>
              <div className="flex gap-2">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                  <input 
                    type="text"
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    placeholder="Enter area name..."
                    className="w-full pl-10 pr-4 py-3 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
                  />
                </div>
                <button 
                  onClick={handleSearch}
                  className="px-6 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 transition-colors"
                >
                  Go
                </button>
              </div>
            </div>

            {selectedLocation && (
              <div className="rounded-2xl overflow-hidden shadow-lg border border-slate-200 aspect-square">
                <iframe
                  width="100%"
                  height="100%"
                  frameBorder="0"
                  src={`https://www.google.com/maps/embed/v1/place?key=${process.env.GOOGLE_MAPS_API_KEY || ''}&q=${encodeURIComponent(selectedLocation)}`}
                  allowFullScreen
                ></iframe>
              </div>
            )}
          </div>

          {/* Visualization */}
          <div className="lg:col-span-2 space-y-8">
            {data.length > 0 ? (
              <>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
                    <h3 className="text-lg font-bold text-slate-800 mb-6">Accident Hotspots</h3>
                    <div className="h-64">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={chartData}>
                          <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                          <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#64748b', fontSize: 12}} />
                          <YAxis axisLine={false} tickLine={false} tick={{fill: '#64748b', fontSize: 12}} />
                          <Tooltip 
                            contentStyle={{borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)'}}
                          />
                          <Bar dataKey="count" fill="#4338ca" radius={[4, 4, 0, 0]} />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </div>

                  <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
                    <h3 className="text-lg font-bold text-slate-800 mb-6">Primary Causes</h3>
                    <div className="h-64">
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie
                            data={pieData}
                            innerRadius={60}
                            outerRadius={80}
                            paddingAngle={5}
                            dataKey="value"
                          >
                            {pieData.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                            ))}
                          </Pie>
                          <Tooltip />
                        </PieChart>
                      </ResponsiveContainer>
                    </div>
                  </div>
                </div>

                <div className="bg-indigo-900 text-white p-8 rounded-3xl shadow-xl relative overflow-hidden">
                  <div className="absolute top-0 right-0 p-4 opacity-10">
                    <FileText size={120} />
                  </div>
                  <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
                    <Database size={24} />
                    AI Insights Summary
                  </h3>
                  {isAnalyzing ? (
                    <div className="flex items-center gap-3">
                      <Loader2 className="animate-spin" />
                      <span>Generating insights...</span>
                    </div>
                  ) : (
                    <p className="text-indigo-100 leading-relaxed text-lg">
                      {insights || "Upload data to see AI-powered safety insights."}
                    </p>
                  )}
                </div>
              </>
            ) : (
              <div className="h-full flex flex-col items-center justify-center text-slate-300 gap-4 border-2 border-dashed border-slate-200 rounded-3xl p-12">
                <Database size={64} className="opacity-20" />
                <p className="text-xl font-medium text-center">
                  Please upload a CSV dataset or search for a location to begin analysis.
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
