import React, { useState, useRef, useEffect } from 'react';
import { Camera, Mic, Play, Square, CheckCircle, AlertTriangle, Loader2, ArrowRight } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { analyzeRoadHazard } from '../services/geminiService';
import { VisionResult, Language, TranslationStrings } from '../types';

interface Props {
  language: Language;
  t: TranslationStrings;
  onResult: (result: VisionResult) => void;
  onProceed: () => void;
}

export default function VisualIntelligence({ language, t, onResult, onProceed }: Props) {
  const [isCameraOpen, setIsCameraOpen] = useState(false);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [isRecording, setIsRecording] = useState(false);
  const [audioBlob, setAudioBlob] = useState<Blob | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState<VisionResult | null>(null);
  
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
      setIsCameraOpen(true);
      setCapturedImage(null);
      setResult(null);
    } catch (err) {
      console.error("Error accessing camera:", err);
    }
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    setIsCameraOpen(false);
  };

  const capturePhoto = () => {
    if (videoRef.current && canvasRef.current) {
      const context = canvasRef.current.getContext('2d');
      if (context) {
        canvasRef.current.width = videoRef.current.videoWidth;
        canvasRef.current.height = videoRef.current.videoHeight;
        context.drawImage(videoRef.current, 0, 0);
        const dataUrl = canvasRef.current.toDataURL('image/jpeg');
        setCapturedImage(dataUrl);
        stopCamera();
      }
    }
  };

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      const chunks: BlobPart[] = [];

      mediaRecorder.ondataavailable = (e) => chunks.push(e.data);
      mediaRecorder.onstop = () => {
        const blob = new Blob(chunks, { type: 'audio/wav' });
        setAudioBlob(blob);
        stream.getTracks().forEach(track => track.stop());
      };

      mediaRecorder.start();
      setIsRecording(true);
    } catch (err) {
      console.error("Error accessing microphone:", err);
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    }
  };

  const handleAnalyze = async () => {
    if (!capturedImage) return;
    setIsAnalyzing(true);
    try {
      let audioBase64: string | undefined;
      if (audioBlob) {
        const reader = new FileReader();
        audioBase64 = await new Promise((resolve) => {
          reader.onloadend = () => resolve(reader.result as string);
          reader.readAsDataURL(audioBlob);
        });
      }
      
      const analysis = await analyzeRoadHazard(capturedImage, language, audioBase64);
      setResult(analysis);
      onResult(analysis);
    } catch (err) {
      console.error("Analysis failed:", err);
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-white/80 backdrop-blur-xl rounded-3xl p-8 shadow-2xl border border-white/20">
        <h2 className="text-3xl font-bold mb-6 flex items-center gap-3">
          <Camera className="text-indigo-600" size={32} />
          {t.visualIntel}
        </h2>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Camera/Capture Section */}
          <div className="space-y-4">
            <div className="relative aspect-video bg-slate-900 rounded-2xl overflow-hidden shadow-inner border-4 border-slate-800">
              {!isCameraOpen && !capturedImage && (
                <div className="absolute inset-0 flex flex-col items-center justify-center text-slate-400 gap-4">
                  <Camera size={64} className="opacity-20" />
                  <button 
                    onClick={startCamera}
                    className="px-8 py-4 bg-indigo-600 hover:bg-indigo-700 text-white rounded-full font-bold shadow-lg transition-all transform hover:scale-105"
                  >
                    {t.openCam}
                  </button>
                </div>
              )}

              {isCameraOpen && (
                <>
                  <video ref={videoRef} autoPlay playsInline className="w-full h-full object-cover" />
                  <div className="absolute bottom-6 left-0 right-0 flex justify-center">
                    <button 
                      onClick={capturePhoto}
                      className="group relative w-20 h-20 flex items-center justify-center"
                    >
                      <div className="absolute inset-0 bg-white rounded-full border-4 border-slate-300 group-hover:scale-110 transition-transform" />
                      <div className="absolute inset-2 bg-white rounded-full border-2 border-slate-800" />
                    </button>
                  </div>
                  <div className="absolute top-4 left-4 bg-red-500 text-white px-3 py-1 rounded-full text-xs font-bold animate-pulse flex items-center gap-2">
                    <div className="w-2 h-2 bg-white rounded-full" />
                    CAMERA ACTIVE
                  </div>
                </>
              )}

              {capturedImage && (
                <img src={capturedImage} className="w-full h-full object-cover" alt="Captured" />
              )}
            </div>

            <div className="flex gap-4">
              {capturedImage && (
                <button 
                  onClick={startCamera}
                  className="flex-1 py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-semibold transition-colors"
                >
                  Retake
                </button>
              )}
              
              <button 
                onClick={isRecording ? stopRecording : startRecording}
                className={`flex-1 py-3 rounded-xl font-semibold flex items-center justify-center gap-2 transition-all ${
                  isRecording ? 'bg-red-500 text-white animate-pulse' : 'bg-indigo-50 text-indigo-700 hover:bg-indigo-100'
                }`}
              >
                {isRecording ? <Square size={20} /> : <Mic size={20} />}
                {isRecording ? 'Stop Recording' : 'Add Audio Note'}
              </button>
            </div>

            {audioBlob && (
              <div className="bg-indigo-50 p-4 rounded-xl flex items-center justify-between">
                <div className="flex items-center gap-3 text-indigo-700">
                  <Play size={20} />
                  <span className="text-sm font-medium">Audio Note Recorded</span>
                </div>
                <button onClick={() => setAudioBlob(null)} className="text-xs text-indigo-400 hover:text-indigo-600 underline">Remove</button>
              </div>
            )}

            {capturedImage && !result && (
              <motion.button
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                whileHover={{ scale: 1.02 }}
                onClick={handleAnalyze}
                disabled={isAnalyzing}
                className="w-full py-5 bg-indigo-600 text-white rounded-2xl font-black text-xl shadow-xl shadow-indigo-200 flex items-center justify-center gap-3 disabled:opacity-50 animate-pulse"
              >
                {isAnalyzing ? <Loader2 className="animate-spin" /> : <CheckCircle />}
                {t.analyzeHazard}
              </motion.button>
            )}
          </div>

          {/* Results Section */}
          <div className="space-y-6">
            <AnimatePresence mode="wait">
              {isAnalyzing ? (
                <motion.div 
                  key="loading"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="h-full flex flex-col items-center justify-center text-slate-400 gap-4"
                >
                  <Loader2 size={48} className="animate-spin text-indigo-600" />
                  <p className="font-medium">AI is analyzing the hazard...</p>
                </motion.div>
              ) : result ? (
                <motion.div
                  key="result"
                  initial={{ x: 20, opacity: 0 }}
                  animate={{ x: 0, opacity: 1 }}
                  className="space-y-6"
                >
                  <div className="flex items-center justify-between">
                    <h3 className="text-2xl font-bold text-slate-800">{t.hazardDetected}</h3>
                    <div className={`px-4 py-1 rounded-full text-sm font-bold ${
                      result.severity === 'High' ? 'bg-red-100 text-red-600' :
                      result.severity === 'Medium' ? 'bg-amber-100 text-amber-600' :
                      'bg-emerald-100 text-emerald-600'
                    }`}>
                      {t.severity}: {result.severity}
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div className="p-5 bg-slate-50 rounded-2xl border border-slate-100">
                      <p className="text-sm uppercase tracking-wider text-slate-400 font-bold mb-2">Type</p>
                      <p className="text-lg font-semibold text-slate-700">{result.hazardType}</p>
                    </div>

                    <div className="p-5 bg-slate-50 rounded-2xl border border-slate-100">
                      <p className="text-sm uppercase tracking-wider text-slate-400 font-bold mb-2">Description</p>
                      <p className="text-slate-600 leading-relaxed">{result.description}</p>
                    </div>

                    {result.transcript && (
                      <div className="p-5 bg-indigo-50 rounded-2xl border border-indigo-100">
                        <p className="text-sm uppercase tracking-wider text-indigo-400 font-bold mb-2">Audio Transcript</p>
                        <p className="text-indigo-700 italic">"{result.transcript}"</p>
                      </div>
                    )}

                    <div className="p-5 bg-emerald-50 rounded-2xl border border-emerald-100">
                      <p className="text-sm uppercase tracking-wider text-emerald-400 font-bold mb-2">Recommendation</p>
                      <p className="text-emerald-700 font-medium">{result.recommendation}</p>
                    </div>
                  </div>

                  <button
                    onClick={onProceed}
                    className="w-full py-4 bg-slate-900 text-white rounded-2xl font-bold flex items-center justify-center gap-3 hover:bg-slate-800 transition-all group"
                  >
                    Proceed to Action
                    <ArrowRight className="group-hover:translate-x-1 transition-transform" />
                  </button>
                </motion.div>
              ) : (
                <div className="h-full flex flex-col items-center justify-center text-slate-300 gap-4 border-2 border-dashed border-slate-200 rounded-3xl">
                  <AlertTriangle size={48} className="opacity-20" />
                  <p className="font-medium">No analysis yet</p>
                </div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>
      <canvas ref={canvasRef} className="hidden" />
    </div>
  );
}
