import { GoogleGenAI } from "@google/genai";
import { VisionResult, Language, AccidentData } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });

export const analyzeRoadHazard = async (
  base64Image: string, 
  language: Language,
  audioBase64?: string
): Promise<VisionResult> => {
  const model = "gemini-3-flash-preview";
  
  const parts: any[] = [
    { text: `Analyze this road hazard image. 
      Identify the hazard (pothole, waterlogging, broken light, etc.), 
      assess severity (Low, Medium, High), and provide a recommendation.
      If audio is provided, transcribe it and incorporate it into the analysis.
      Respond in the following JSON format:
      {
        "hazardType": "string",
        "severity": "Low" | "Medium" | "High",
        "description": "string",
        "transcript": "string (if audio provided)",
        "recommendation": "string"
      }
      The response must be in ${language === 'en' ? 'English' : language}.` }
  ];

  parts.push({
    inlineData: {
      data: base64Image.split(',')[1],
      mimeType: "image/jpeg"
    }
  });

  if (audioBase64) {
    parts.push({
      inlineData: {
        data: audioBase64.split(',')[1],
        mimeType: "audio/wav"
      }
    });
  }

  const result = await ai.models.generateContent({
    model,
    contents: [{ role: 'user', parts }],
    config: { responseMimeType: "application/json" }
  });

  return JSON.parse(result.text || '{}');
};

export const generateAnalyticsInsights = async (data: AccidentData[], language: Language): Promise<string> => {
  const model = "gemini-3-flash-preview";
  const prompt = `Analyze the following accident data and provide a summary of key findings (hotspots, common causes, time patterns).
    Data: ${JSON.stringify(data.slice(0, 50))}
    Respond in ${language === 'en' ? 'English' : language}. Keep it professional and concise.`;

  const result = await ai.models.generateContent({
    model,
    contents: [{ role: 'user', parts: [{ text: prompt }] }]
  });

  return result.text || '';
};

export const generateComplaintLetter = async (
  hazard: VisionResult, 
  analytics: string, 
  authority: string,
  location: string,
  language: Language
): Promise<string> => {
  const model = "gemini-3-flash-preview";
  const prompt = `Generate a formal complaint letter to ${authority} regarding a ${hazard.hazardType} at ${location}.
    Incorporate these analytics insights: ${analytics}.
    The hazard was detected as ${hazard.severity} severity.
    Description: ${hazard.description}.
    Respond in ${language === 'en' ? 'English' : language}. Use a professional tone.`;

  const result = await ai.models.generateContent({
    model,
    contents: [{ role: 'user', parts: [{ text: prompt }] }]
  });

  return result.text || '';
};

export const validateAuthority = async (
  hazardType: string,
  authorityRole: string,
  language: Language
): Promise<{ isCorrect: boolean; message: string }> => {
  const model = "gemini-3-flash-preview";
  const prompt = `Is a "${authorityRole}" the correct person to handle a "${hazardType}" road hazard? 
    Respond in JSON: { "isCorrect": boolean, "message": "string explanation in ${language}" }`;

  const result = await ai.models.generateContent({
    model,
    contents: [{ role: 'user', parts: [{ text: prompt }] }],
    config: { responseMimeType: "application/json" }
  });

  return JSON.parse(result.text || '{"isCorrect": false, "message": "Error validating"}');
};
