export type Severity = 'Low' | 'Medium' | 'High';

export interface VisionResult {
  hazardType: string;
  severity: Severity;
  description: string;
  transcript?: string;
  recommendation: string;
}

export interface AccidentData {
  location: string;
  time: string;
  severity: string;
  cause: string;
  lat?: number;
  lng?: number;
}

export interface Authority {
  id: string;
  name: string;
  role: string;
  department: string;
}

export type Language = 'en' | 'hi' | 'ta' | 'te' | 'es' | 'fr' | 'kn' | 'ml';

export interface TranslationStrings {
  appTitle: string;
  visualIntel: string;
  dataAnalytics: string;
  civicReporting: string;
  openCam: string;
  clickPhoto: string;
  analyzeHazard: string;
  uploadCsv: string;
  searchLocation: string;
  generateLetter: string;
  sendReport: string;
  severity: string;
  hazardDetected: string;
  authorityValidation: string;
  trackingStatus: string;
  aboutProject: string;
  language: string;
}
